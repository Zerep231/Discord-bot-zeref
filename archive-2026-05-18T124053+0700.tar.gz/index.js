require('dotenv').config();
const { 
    Client, 
    GatewayIntentBits, 
    Collection, 
    REST, 
    Routes 
} = require('discord.js');
const fs = require('fs');
const path = require('path');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
    ]
});

client.commands = new Collection();
client.cooldowns = new Collection();
client.slashCommands = [];

const CONFIG_FILE = path.join(__dirname, 'embed_config.json');
const defaultConfig = {
    title: '🌐 ONIC NETWORK',
    description: 'Bạn cần IP Server?\n- onic.asia\n\nServer hỗ trợ JAVA & BEDROCK\n- 1.26+\n\nNếu bạn gặp lỗi hoặc có vấn đề khi kết nối đến máy chủ hãy tạo ticket',
    image: 'https://64.media.tumblr.com/e0137890409b2ef9feda3a8c4e7cfb37/531b611a0db66eb0-35/s1280x1920/36ab6b75b1f5e3209b04f6151460db2917de3db6.gif',
    color: 0x00FF00,
    channelId: null,
    messageId: null
};

client.config = {};
if (fs.existsSync(CONFIG_FILE)) {
    client.config = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
} else {
    client.config = defaultConfig;
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(defaultConfig, null, 2));
}

client.saveConfig = function() {
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(client.config, null, 2));
};

client.colors = [0x00FF00, 0xFF0000, 0x0000FF, 0xFFD700, 0xFF69B4, 0x9B59B6, 0xE67E22, 0x1ABC9C, 0xE74C3C, 0x3498DB];
client.getRandomColor = function() {
    return client.colors[Math.floor(Math.random() * client.colors.length)];
};

const featuresPath = path.join(__dirname, 'ft');
if (!fs.existsSync(featuresPath)) {
    fs.mkdirSync(featuresPath, { recursive: true });
}

const featureFiles = fs.readdirSync(featuresPath).filter(file => file.endsWith('.js'));
for (const file of featureFiles) {
    const filePath = path.join(featuresPath, file);
    try {
        const feature = require(filePath);
        if (feature.name) {
            client.commands.set(feature.name, feature);
            if (feature.slashCommand) {
                client.slashCommands.push(feature.slashCommand.toJSON());
            }
            console.log(`✅ Đã load: ${feature.name}`);
        }
    } catch (error) {
        console.error(`❌ Lỗi load ${file}:`, error.message);
    }
}

client.once('clientReady', async () => {
    console.log(`✅ Bot đã sẵn sàng: ${client.user.tag}`);
    client.user.setStatus('idle');
    client.user.setActivity({ name: 'onic.asia', type: 4 });

    if (client.slashCommands.length > 0) {
        const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);
        try {
            console.log(`🔄 Đang đăng ký ${client.slashCommands.length} slash commands...`);
            await rest.put(
                Routes.applicationCommands(client.user.id),
                { body: client.slashCommands }
            );
            console.log('✅ Đã đăng ký slash commands thành công!');
        } catch (error) {
            console.error('❌ Lỗi đăng ký slash commands:', error);
        }
    }
});

client.on('interactionCreate', async (interaction) => {
    if (interaction.isChatInputCommand()) {
        const command = client.commands.get(interaction.commandName);
        if (command && command.handleCommand) {
            try {
                await command.handleCommand(client, interaction);
            } catch (err) {
                console.error(err);
            }
        }
    }

    if (interaction.isModalSubmit()) {
        for (const [name, feature] of client.commands) {
            if (feature.handleModal && interaction.customId.includes(name)) {
                try {
                    await feature.handleModal(client, interaction);
                } catch (err) {
                    console.error(err);
                }
                break;
            }
        }
    }
});

client.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    for (const [name, feature] of client.commands) {
        if (feature.handleMessage) {
            try {
                const shouldContinue = await feature.handleMessage(client, message);
                if (shouldContinue === false) break;
            } catch (err) {
                console.error(err);
            }
        }
    }
});

client.login(process.env.TOKEN);
