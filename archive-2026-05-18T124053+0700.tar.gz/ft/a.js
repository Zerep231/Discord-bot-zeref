const { 
    SlashCommandBuilder, 
    MessageFlags,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    ActionRowBuilder,
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    MediaGalleryBuilder,
    MediaGalleryItemBuilder
} = require('discord.js');

module.exports = {
    name: 'setip',
    
    slashCommand: new SlashCommandBuilder()
        .setName('setip')
        .setDescription('Cấu hình IP hiển thị')
        .addStringOption(option => option
            .setName('option')
            .setDescription('Chọn tùy chọn cấu hình')
            .setRequired(true)
            .addChoices(
                { name: '✏️ Sửa nội dung hiển thị', value: 'embed' },
                { name: '📌 Tạo hiển thị cố định tại channel', value: 'channel' }
            )),

    createV2Container(client, author) {
        const randomColor = client.getRandomColor();
        
        const container = new ContainerBuilder()
            .setAccentColor(randomColor);

        if (client.config.title) {
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**${client.config.title}**`)
            );
        }

        container.addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(1)
        );

        if (client.config.description) {
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(client.config.description)
            );
        }

        container.addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(1)
        );

        if (client.config.image) {
            const mediaGallery = new MediaGalleryBuilder().addItems(
                new MediaGalleryItemBuilder().setURL(client.config.image)
            );
            container.addMediaGalleryComponents(mediaGallery);
        }

        container.addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(1)
        );

        const footerText = author 
            ? `-# Yêu cầu bởi ${author.tag} • ${new Date().toLocaleTimeString('vi-VN')}`
            : `-# ONIC NETWORK • ${new Date().toLocaleTimeString('vi-VN')}`;
        
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(footerText)
        );

        return container;
    },

    async updateFixedMessage(client) {
        if (!client.config.channelId || !client.config.messageId) return;

        try {
            const channel = await client.channels.fetch(client.config.channelId);
            if (!channel) return;

            const message = await channel.messages.fetch(client.config.messageId);
            if (!message) return;

            const container = this.createV2Container(client);
            
            await message.edit({
                flags: MessageFlags.IsComponentsV2,
                components: [container]
            });
            console.log('✅ Đã cập nhật message cố định với Components V2');
        } catch (error) {
            console.error('❌ Lỗi cập nhật message cố định:', error);
        }
    },

    async handleCommand(client, interaction) {
        const option = interaction.options.getString('option');

        if (option === 'embed') {
            const modal = new ModalBuilder()
                .setCustomId('setip_modal')
                .setTitle('Cấu hình hiển thị IP');

            const titleInput = new TextInputBuilder()
                .setCustomId('title')
                .setLabel('Tiêu đề')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('Nhập tiêu đề...')
                .setValue(client.config.title)
                .setRequired(false);

            const descriptionInput = new TextInputBuilder()
                .setCustomId('description')
                .setLabel('Mô tả')
                .setStyle(TextInputStyle.Paragraph)
                .setPlaceholder('Nhập mô tả...')
                .setValue(client.config.description)
                .setRequired(false);

            const imageInput = new TextInputBuilder()
                .setCustomId('image')
                .setLabel('URL Ảnh')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('https://example.com/image.gif')
                .setValue(client.config.image || '')
                .setRequired(false);

            const firstRow = new ActionRowBuilder().addComponents(titleInput);
            const secondRow = new ActionRowBuilder().addComponents(descriptionInput);
            const thirdRow = new ActionRowBuilder().addComponents(imageInput);

            modal.addComponents(firstRow, secondRow, thirdRow);

            await interaction.showModal(modal);
        }

        if (option === 'channel') {
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });

            const container = this.createV2Container(client);

            const sentMessage = await interaction.channel.send({
                flags: MessageFlags.IsComponentsV2,
                components: [container]
            });

            client.config.channelId = interaction.channel.id;
            client.config.messageId = sentMessage.id;
            client.saveConfig();

            await interaction.editReply({ 
                content: `✅ **Đã tạo hiển thị cố định trong channel này!**\nNội dung sẽ tự động cập nhật khi bạn dùng \`/setip\` chọn **Sửa nội dung**`,
                flags: MessageFlags.Ephemeral 
            });
        }
    },

    async handleModal(client, interaction) {
        if (interaction.customId !== 'setip_modal') return;

        await interaction.deferReply({ flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral });

        const title = interaction.fields.getTextInputValue('title');
        const description = interaction.fields.getTextInputValue('description');
        const image = interaction.fields.getTextInputValue('image');

        if (title) client.config.title = title;
        if (description) client.config.description = description;
        if (image) client.config.image = image;

        client.saveConfig();
        await this.updateFixedMessage(client);

        const previewContainer = this.createV2Container(client, interaction.user);

        const successContainer = new ContainerBuilder()
            .setAccentColor(0x00FF00)
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent('✅ **Cấu hình đã được cập nhật!** Dưới đây là bản xem trước:')
            );

        await interaction.editReply({ 
            flags: MessageFlags.IsComponentsV2,
            components: [successContainer, previewContainer]
        });
    },

    async handleMessage(client, message) {
        const content = message.content.trim().toLowerCase();
        const ipRegex = /\bip\b/;
        const commandRegex = /^[?!]ip$/;
        
        if (ipRegex.test(content) || commandRegex.test(content)) {
            const cooldownKey = `ip_${message.author.id}`;
            const now = Date.now();
            const cooldownAmount = 30 * 1000;

            if (client.cooldowns.has(cooldownKey)) {
                const expirationTime = client.cooldowns.get(cooldownKey) + cooldownAmount;
                if (now < expirationTime) {
                    const timeLeft = Math.ceil((expirationTime - now) / 1000);
                    
                    const cooldownContainer = new ContainerBuilder()
                        .setAccentColor(0xFFA500)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`⏰ **Vui lòng đợi ${timeLeft} giây nữa!**`)
                        );
                    
                    await message.reply({ 
                        flags: MessageFlags.IsComponentsV2,
                        components: [cooldownContainer]
                    }).catch(() => {});
                    return false;
                }
            }

            client.cooldowns.set(cooldownKey, now);
            setTimeout(() => client.cooldowns.delete(cooldownKey), cooldownAmount);

            const container = this.createV2Container(client, message.author);
            await message.reply({ 
                flags: MessageFlags.IsComponentsV2,
                components: [container]
            });
            
            return false;
        }
        
        return true;
    }
};