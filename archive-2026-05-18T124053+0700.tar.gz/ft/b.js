const { createCanvas, loadImage, registerFont } = require('canvas');
const { statusJava } = require('node-mcstatus');
const { 
    AttachmentBuilder,
    ContainerBuilder,
    TextDisplayBuilder,
    MediaGalleryBuilder,
    MediaGalleryItemBuilder,
    MessageFlags
} = require('discord.js');
const path = require('path');

// ✅ Register Minecraft font chính
try {
    registerFont(path.join(__dirname, './fonts/Minecraftia.ttf'), { family: 'MinecraftFont' });
} catch (e) {
    console.error("LỖI: Không tìm thấy file Minecraftia.ttf!");
}

// ✅ Register font fallback hỗ trợ Unicode (NotoSans hoặc DejaVu)
try {
    registerFont(path.join(__dirname, './fonts/NotoSans-Regular.ttf'), { family: 'NotoSans' });
} catch (e) {
    try {
        registerFont(path.join(__dirname, './fonts/DejaVuSans.ttf'), { family: 'NotoSans' });
    } catch (e2) {
        console.error("LỖI: Không tìm thấy font Unicode fallback!");
    }
}

function roundRect(ctx, x, y, w, h, r) {
    if (w < 2 * r) r = w / 2;
    if (h < 2 * r) r = h / 2;
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
}

// ✅ Làm sạch Minecraft color/format codes
function hardCleanMOTD(text) {
    if (!text) return "";
    let cleaned = text
        .replace(/\u00A7[0-9a-fk-orA-FK-OR]/g, '')
        .replace(/&[0-9a-fk-orA-FK-OR]/g, '')
        .replace(/\u00A7./g, '')
        .replace(/\u00A7/g, '')
        .replace(/§./g, '')
        .replace(/§/g, '');
    return cleaned.replace(/\s+/g, ' ').trim();
}

// ✅ Kiểm tra 1 ký tự có phải Unicode không (ngoài Basic Latin & Latin-1)
function isUnicodeChar(char) {
    const code = char.codePointAt(0);
    return code > 0x00FF;
}

// ✅ Vẽ MOTD từng segment - ký tự ASCII dùng MinecraftFont, Unicode dùng NotoSans
function drawMotdTextSmart(ctx, text, x, y, size, color) {
    if (!text) return;
    ctx.fillStyle = color;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';

    let currentX = x;
    let i = 0;

    while (i < text.length) {
        // Lấy full codepoint (hỗ trợ surrogate pairs)
        const char = String.fromCodePoint(text.codePointAt(i));
        const isUnicode = isUnicodeChar(char);

        // Gom các ký tự cùng loại font thành 1 segment để vẽ 1 lần
        let segment = char;
        let j = i + char.length;

        while (j < text.length) {
            const nextChar = String.fromCodePoint(text.codePointAt(j));
            if (isUnicodeChar(nextChar) !== isUnicode) break;
            segment += nextChar;
            j += nextChar.length;
        }

        // Chọn font theo loại ký tự
        if (isUnicode) {
            ctx.font = `${size}px "NotoSans", sans-serif`;
        } else {
            ctx.font = `${size}px "MinecraftFont", sans-serif`;
        }

        ctx.fillText(segment, currentX, y);
        currentX += ctx.measureText(segment).width;
        i = j;
    }
}

module.exports = {
    name: 'status',
    
    async handleMessage(client, message) {
        const prefixes = ['!', '.'];
        const content = message.content.toLowerCase();
        const activePrefix = prefixes.find(p => content.startsWith(p));
        if (!activePrefix) return true;

        const commandBody = content.slice(activePrefix.length);
        if (!commandBody.startsWith('status') && !commandBody.startsWith('online')) return true;

        const args = message.content.split(' ').slice(1).join(' ');
        const ip = args || 'mc.onic.asia';

        message.channel.sendTyping();

        try {
            const data = await statusJava(ip);

            if (!data.online) {
                const offlineContainer = new ContainerBuilder()
                    .setAccentColor(0xFF0000)
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`### ❌ TRẠNG THÁI\n> Máy chủ **${ip}** Offline.`)
                    );
                return message.reply({ flags: MessageFlags.IsComponentsV2, components: [offlineContainer] });
            }

            const canvas = createCanvas(2000, 250);
            const ctx = canvas.getContext('2d');

            ctx.fillStyle = '#0a0a0a';
            roundRect(ctx, 0, 0, 2000, 250, 20);
            ctx.fill();

            if (data.icon) {
                try {
                    const base64Data = data.icon.replace(/^data:image\/png;base64,/, "");
                    const iconImg = await loadImage(Buffer.from(base64Data, 'base64'));
                    ctx.drawImage(iconImg, 45, 45, 160, 160);
                } catch (e) {}
            }

            ctx.textBaseline = 'top';
            ctx.textAlign = 'left';

            // ✅ Vẽ tiêu đề server (toàn ASCII, dùng MinecraftFont)
            ctx.fillStyle = '#ffffff';
            ctx.font = '50px "MinecraftFont", sans-serif';
            ctx.fillText("A Minecraft Server", 240, 50);

            // ✅ Lấy MOTD
            const motdSource = data.motd?.clean || data.motd?.raw || "";
            const lines = motdSource.split('\n');

            const line1 = data.motd?.clean
                ? (lines[0]?.trim() || "")
                : hardCleanMOTD(lines[0]);
            const line2 = data.motd?.clean
                ? (lines[1]?.trim() || "")
                : hardCleanMOTD(lines[1]);

            // ✅ Vẽ MOTD với font switching per-character
            drawMotdTextSmart(ctx, line1, 240, 120, 38, '#AAAAAA');
            drawMotdTextSmart(ctx, line2, 240, 175, 38, '#AAAAAA');

            // ✅ Vẽ player count và Online status
            ctx.textAlign = 'right';
            const onlineText = "Online";
            ctx.fillStyle = '#55FF55';
            ctx.font = '42px "MinecraftFont", sans-serif';
            ctx.fillText(onlineText, 1950, 50);

            const onlineWidth = ctx.measureText(onlineText).width;
            ctx.fillStyle = '#ffffff';
            ctx.fillText(`${data.players.online}/${data.players.max}`, 1950 - onlineWidth - 30, 50);

            const attachment = new AttachmentBuilder(canvas.toBuffer(), { name: 'status.png' });
            
            const percentage = Math.round((data.players.online / data.players.max) * 100) || 0;
            const container = new ContainerBuilder()
                .setAccentColor(client.getRandomColor ? client.getRandomColor() : 0x00FF00)
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `### THÔNG TIN MÁY CHỦ\n` +
                        `> **Địa chỉ:** \`${ip}\`\n` +
                        `> **Người chơi:** \`${data.players.online}/${data.players.max}\` (${percentage}%)`
                    )
                )
                .addMediaGalleryComponents(
                    new MediaGalleryBuilder().addItems(
                        new MediaGalleryItemBuilder().setURL('attachment://status.png')
                    )
                )
                .addTextDisplayComponents(new TextDisplayBuilder().setContent('-# ONIC NETWORK'));

            await message.reply({
                flags: MessageFlags.IsComponentsV2,
                components: [container],
                files: [attachment]
            });

        } catch (error) {
            console.error(error);
            message.reply("Đã xảy ra lỗi.");
        }
        return false;
    }
};