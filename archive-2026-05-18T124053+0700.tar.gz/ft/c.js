const { 
    MessageFlags, 
    ContainerBuilder, 
    TextDisplayBuilder,
    SlashCommandBuilder
} = require('discord.js');
const fs = require('fs');
const path = require('path');

const DICTIONARY_FILES = [
    path.join(__dirname, '..', 'tu-dien-wiktionary.json'),
    path.join(__dirname, '..', 'tu-dien-tudientv.json'),
    path.join(__dirname, '..', 'tu-dien.json')
];

let phraseList = new Set();
let phrasesByFirstWord = new Map();

function normalize(text) {
    return text.toLowerCase().trim().replace(/\s+/g, ' ');
}

function countWords(phrase) {
    return normalize(phrase).split(' ').length;
}

function getFirstWord(phrase) {
    return normalize(phrase).split(' ')[0];
}

function getLastWord(phrase) {
    const words = normalize(phrase).split(' ');
    return words[words.length - 1];
}

function loadJsonFileSync(filePath) {
    try {
        if (!fs.existsSync(filePath)) return [];
        const content = fs.readFileSync(filePath, 'utf8');
        return JSON.parse(content);
    } catch (e) {
        console.error(`❌ Lỗi load ${path.basename(filePath)}:`, e.message);
        return [];
    }
}

function loadJsonlFileSync(filePath) {
    try {
        if (!fs.existsSync(filePath)) return [];
        const content = fs.readFileSync(filePath, 'utf8');
        const lines = content.split('\n').filter(line => line.trim());
        const items = [];
        for (const line of lines) {
            try {
                items.push(JSON.parse(line));
            } catch (e) {}
        }
        return items;
    } catch (e) {
        return [];
    }
}

function addPhraseToDictionary(phrase) {
    const normalized = normalize(phrase);
    if (!normalized) return false;
    if (countWords(normalized) !== 2) return false;
    
    if (phraseList.has(normalized)) return false;
    
    phraseList.add(normalized);
    
    const firstWord = getFirstWord(normalized);
    if (!phrasesByFirstWord.has(firstWord)) {
        phrasesByFirstWord.set(firstWord, new Set());
    }
    phrasesByFirstWord.get(firstWord).add(normalized);
    
    return true;
}

function loadAllDictionaries() {
    phraseList.clear();
    phrasesByFirstWord.clear();
    
    let totalLoaded = 0;
    
    const file1 = DICTIONARY_FILES[0];
    let items1 = loadJsonFileSync(file1);
    if (items1.length === 0) items1 = loadJsonlFileSync(file1);
    
    let loaded1 = 0;
    for (const item of items1) {
        const text = item.text || item.word || item.phrase || item;
        if (typeof text === 'string' && addPhraseToDictionary(text)) {
            loaded1++;
        }
    }
    totalLoaded += loaded1;
    console.log(`✅ ${path.basename(file1)}: ${loaded1} cụm từ`);
    
    const file2 = DICTIONARY_FILES[1];
    let items2 = loadJsonFileSync(file2);
    if (items2.length === 0) items2 = loadJsonlFileSync(file2);
    
    let loaded2 = 0;
    for (const item of items2) {
        const text = item.text || item.word || item.phrase || item;
        if (typeof text === 'string' && addPhraseToDictionary(text)) {
            loaded2++;
        }
    }
    totalLoaded += loaded2;
    console.log(`✅ ${path.basename(file2)}: ${loaded2} cụm từ`);
    
    const file3 = DICTIONARY_FILES[2];
    const contributions = loadJsonFileSync(file3);
    let loaded3 = 0;
    
    for (const item of contributions) {
        if (item.approved === true && item.text) {
            if (addPhraseToDictionary(item.text)) {
                loaded3++;
            }
        }
    }
    totalLoaded += loaded3;
    console.log(`✅ ${path.basename(file3)}: ${loaded3} cụm từ đã duyệt`);
    console.log(`📚 Tổng cộng ${totalLoaded} cụm từ hợp lệ (đúng 2 từ)`);
}

function phraseExists(phrase) {
    return phraseList.has(normalize(phrase));
}

function findPhrasesStartingWith(word) {
    return phrasesByFirstWord.get(normalize(word)) || new Set();
}

function getRandomStartPhrase() {
    const phrasesArray = Array.from(phraseList);
    if (phrasesArray.length === 0) return null;
    return phrasesArray[Math.floor(Math.random() * phrasesArray.length)];
}

async function addContribution(phrase, source, contributor) {
    const normalized = normalize(phrase);
    
    const wordCount = countWords(normalized);
    if (wordCount !== 2) {
        return { success: false, reason: `❌ Cụm từ phải có **đúng 2 từ**! (Bạn đã nhập ${wordCount} từ)` };
    }
    
    if (phraseList.has(normalized)) {
        return { success: false, reason: '❌ Cụm từ này đã tồn tại trong từ điển!' };
    }
    
    const contributionFile = DICTIONARY_FILES[2];
    
    if (!fs.existsSync(contributionFile)) {
        fs.writeFileSync(contributionFile, JSON.stringify([], null, 2));
    }
    
    try {
        const content = await fs.promises.readFile(contributionFile, 'utf8');
        const contributions = JSON.parse(content);
        
        for (const item of contributions) {
            if (item.text && normalize(item.text) === normalized) {
                return { success: false, reason: '❌ Cụm từ này đã có trong danh sách chờ duyệt!' };
            }
        }
        
        const newEntry = {
            text: phrase,
            source: source,
            contributor: contributor,
            timestamp: new Date().toISOString(),
            approved: false
        };
        
        contributions.push(newEntry);
        await fs.promises.writeFile(contributionFile, JSON.stringify(contributions, null, 2));
        
        return { success: true, entry: newEntry };
    } catch (error) {
        console.error('❌ Lỗi đọc/ghi file đóng góp:', error);
        return { success: false, reason: '❌ Lỗi hệ thống, vui lòng thử lại sau!' };
    }
}

function reloadDictionary() {
    loadAllDictionaries();
}

loadAllDictionaries();

const gameState = {
    active: false,
    currentPhrase: null,
    usedPhrases: new Set(),
    currentChannel: null,
    lastPlayer: null,
    tempMessages: new Map()
};

module.exports = {
    name: 'wordchain',
    
    slashCommand: new SlashCommandBuilder()
        .setName('wordchain')
        .setDescription('Đóng góp cụm từ vào từ điển')
        .addStringOption(option => option
            .setName('tudien')
            .setDescription('Nhập cụm từ (đúng 2 từ)')
            .setRequired(true)
            .setMaxLength(100))
        .addStringOption(option => option
            .setName('nguon')
            .setDescription('Nguồn của cụm từ')
            .setRequired(true)
            .setMaxLength(50)),
    
    resetGame() {
        gameState.active = false;
        gameState.currentPhrase = null;
        gameState.usedPhrases.clear();
        gameState.currentChannel = null;
        gameState.lastPlayer = null;
        
        for (const [id, timeout] of gameState.tempMessages) {
            clearTimeout(timeout);
        }
        gameState.tempMessages.clear();
    },
    
    async deleteAfter(message, seconds = 5) {
        const timeout = setTimeout(async () => {
            try {
                await message.delete();
            } catch (e) {}
            gameState.tempMessages.delete(message.id);
        }, seconds * 1000);
        
        gameState.tempMessages.set(message.id, timeout);
    },
    
    async handleCommand(client, interaction) {
        const phrase = interaction.options.getString('tudien');
        const source = interaction.options.getString('nguon');
        const contributor = interaction.user.tag;
        
        await interaction.deferReply({ ephemeral: true });
        
        try {
            const result = await addContribution(phrase, source, contributor);
            
            if (result.success) {
                await interaction.editReply({
                    content: `✅ **Đóng góp thành công!**\n\n` +
                             `📝 **Cụm từ:** \`${phrase}\`\n` +
                             `📚 **Nguồn:** ${source}\n` +
                             `👤 **Người đóng góp:** ${contributor}\n` +
                             `📅 **Thời gian:** ${new Date().toLocaleString('vi-VN')}\n\n` +
                             `⏳ *Cụm từ của bạn đang chờ admin duyệt!*`
                });
            } else {
                await interaction.editReply({
                    content: result.reason
                });
            }
        } catch (error) {
            console.error('❌ Lỗi trong handleCommand:', error);
            await interaction.editReply({
                content: '❌ Đã xảy ra lỗi, vui lòng thử lại sau!'
            });
        }
    },
    
    async handleMessage(client, message) {
        const prefix = '!';
        const content = message.content.trim();
        const lowerContent = content.toLowerCase();
        
        if (lowerContent === `${prefix}reload`) {
            reloadDictionary();
            const stats = this.getStats();
            await message.reply(`✅ Đã reload từ điển!\n📚 Tổng: ${stats.totalPhrases} cụm từ`);
            return false;
        }
        
        if (lowerContent === `${prefix}start` || lowerContent === `${prefix}noitu`) {
            this.resetGame();
            
            const startPhrase = getRandomStartPhrase();
            if (!startPhrase) {
                await message.reply('❌ Không thể bắt đầu game, từ điển trống!');
                return false;
            }
            
            gameState.active = true;
            gameState.currentPhrase = startPhrase;
            gameState.usedPhrases.add(normalize(startPhrase));
            gameState.currentChannel = message.channel.id;
            
            const lastWord = getLastWord(startPhrase);
            
            const startContainer = new ContainerBuilder()
                .setAccentColor(0x00FF00)
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `🎮 **TRÒ CHƠI NỐI TỪ BẮT ĐẦU!**\n\n` +
                        `📌 **Cụm từ bắt đầu:** \`${startPhrase}\`\n` +
                        `🔤 **Từ cần nối:** \`${lastWord}\`\n\n` +
                        `*Gõ cụm từ bắt đầu bằng từ **${lastWord}** để nối*\n` +
                        `*Bot sẽ react ✅ nếu đúng, ❌ nếu sai*`
                    )
                );
            
            await message.reply({
                flags: MessageFlags.IsComponentsV2,
                components: [startContainer]
            });
            
            return false;
        }
        
        if (lowerContent === `${prefix}stop` || lowerContent === `${prefix}end`) {
            if (gameState.active && gameState.currentChannel === message.channel.id) {
                const usedCount = gameState.usedPhrases.size;
                this.resetGame();
                
                const stopContainer = new ContainerBuilder()
                    .setAccentColor(0xFFA500)
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            `🛑 **Game đã kết thúc!**\n📊 Tổng số cụm từ đã dùng: **${usedCount}**`
                        )
                    );
                
                await message.reply({
                    flags: MessageFlags.IsComponentsV2,
                    components: [stopContainer]
                });
            }
            return false;
        }
        
        if (lowerContent === `${prefix}current` || lowerContent === `${prefix}tu`) {
            if (gameState.active && gameState.currentChannel === message.channel.id) {
                const lastWord = getLastWord(gameState.currentPhrase);
                
                await message.reply(
                    `📌 **Cụm từ hiện tại:** \`${gameState.currentPhrase}\`\n` +
                    `🔤 **Cần nối với từ:** \`${lastWord}\``
                );
            }
            return false;
        }
        
        if (lowerContent === `${prefix}goiy` || lowerContent === `${prefix}hint`) {
            if (gameState.active && gameState.currentChannel === message.channel.id) {
                const lastWord = getLastWord(gameState.currentPhrase);
                const possible = findPhrasesStartingWith(lastWord);
                const available = Array.from(possible)
                    .filter(p => !gameState.usedPhrases.has(p))
                    .slice(0, 10);
                
                if (available.length === 0) {
                    await message.reply(`❌ Không còn cụm từ nào bắt đầu bằng \`${lastWord}\`!`);
                } else {
                    await message.reply(
                        `💡 **Gợi ý cụm từ bắt đầu bằng "${lastWord}":**\n` +
                        available.map(p => `• ${p}`).join('\n')
                    );
                }
            }
            return false;
        }
        
        if (lowerContent === `${prefix}stats` || lowerContent === `${prefix}thongke`) {
            const stats = this.getStats();
            await message.reply(
                `📊 **Thống kê từ điển**\n` +
                `📚 Tổng số cụm từ: **${stats.totalPhrases}**\n` +
                `🔤 Số từ đầu khác nhau: **${stats.totalFirstWords}**`
            );
            return false;
        }
        
        if (lowerContent.startsWith(`${prefix}donggop`)) {
            const args = content.slice(prefix.length + 7).trim().split('|');
            if (args.length < 2) {
                await message.reply('Cách dùng: `!donggop cụm từ | nguồn`');
                return false;
            }
            
            const phrase = args[0].trim();
            const source = args[1].trim();
            const result = await addContribution(phrase, source, message.author.tag);
            
            if (result.success) {
                await message.reply(
                    `✅ **Đóng góp thành công!**\n` +
                    `📝 Cụm từ: \`${phrase}\`\n` +
                    `📚 Nguồn: ${source}\n` +
                    `⏳ Đang chờ admin duyệt!`
                );
            } else {
                const errorMsg = await message.reply(result.reason);
                this.deleteAfter(errorMsg, 5);
            }
            return false;
        }
        
        if (!gameState.active || gameState.currentChannel !== message.channel.id) {
            return true;
        }
        
        const userPhrase = content;
        const normalizedPhrase = normalize(userPhrase);
        
        if (countWords(userPhrase) !== 2) {
            return true;
        }
        
        if (gameState.lastPlayer === message.author.id) {
            const errorMsg = await message.reply(`⏰ **${message.author.username}**, bạn vừa nối rồi! Hãy đợi người khác nối.`);
            this.deleteAfter(errorMsg, 5);
            return false;
        }
        
        if (!phraseExists(userPhrase)) {
            await message.react('❌');
            const errorMsg = await message.reply(`❌ Cụm từ **"${userPhrase}"** không có trong từ điển!`);
            this.deleteAfter(errorMsg, 5);
            return false;
        }
        
        if (gameState.usedPhrases.has(normalizedPhrase)) {
            await message.react('❌');
            const errorMsg = await message.reply(`❌ Cụm từ **"${userPhrase}"** đã được dùng rồi!`);
            this.deleteAfter(errorMsg, 5);
            return false;
        }
        
        const requiredWord = getLastWord(gameState.currentPhrase);
        const userFirstWord = getFirstWord(userPhrase);
        
        if (requiredWord !== userFirstWord) {
            await message.react('❌');
            const errorMsg = await message.reply(
                `❌ **Sai luật!**\n` +
                `Cụm từ **"${gameState.currentPhrase}"** có từ cuối là **"${requiredWord}"**\n` +
                `Bạn phải nối cụm từ bắt đầu bằng **"${requiredWord}"**`
            );
            this.deleteAfter(errorMsg, 5);
            return false;
        }
        
        gameState.usedPhrases.add(normalizedPhrase);
        gameState.currentPhrase = userPhrase;
        gameState.lastPlayer = message.author.id;
        
        await message.react('✅');
        
        const nextRequiredWord = getLastWord(userPhrase);
        const possibleNext = findPhrasesStartingWith(nextRequiredWord);
        const availableNext = Array.from(possibleNext).filter(p => !gameState.usedPhrases.has(p));
        
        if (availableNext.length === 0) {
            const winContainer = new ContainerBuilder()
                .setAccentColor(0xFFD700)
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `🏆 **${message.author.username} ĐÃ CHIẾN THẮNG!**\n\n` +
                        `📌 Cụm từ cuối cùng: **${userPhrase}**\n` +
                        `🔤 Từ cần nối tiếp: **${nextRequiredWord}**\n` +
                        `❌ Không còn cụm từ nào bắt đầu bằng từ này! (Nếu còn từ điển nào có thể nối tiếp hãy sử dụng !dong-gop-tu-dien)\n\n` +
                        `📊 Tổng số cụm từ đã dùng: **${gameState.usedPhrases.size}**\n` +
                        `🎮 Gõ \`!start\` để chơi lại!`
                    )
                );
            
            await message.reply({
                flags: MessageFlags.IsComponentsV2,
                components: [winContainer]
            });
            
            this.resetGame();
        }
        
        return false;
    },
    
    getStats() {
        return {
            totalPhrases: phraseList.size,
            totalFirstWords: phrasesByFirstWord.size
        };
    }
};